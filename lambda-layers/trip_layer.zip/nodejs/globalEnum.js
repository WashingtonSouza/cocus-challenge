const enumParams = {
  ARG_TYPE: {
    BODY: 'body',
    QUERYSTRING: 'queryStringParameters',
  }
}

module.exports = enumParams
